#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>

using namespace std;

class GroceryTracker {
public:
    // Constructor to load items from file
    GroceryTracker(const string& filename) {
        dataFile = filename;       // NEW: store filename
        LoadData(dataFile);
    }
    void AddItem() {
        string item;
        int quantity;

        cout << "Enter item name to add: ";
        getline(cin, item);
        cout << "Enter quantity: ";
        cin >> quantity;
        cin.ignore();

        itemQuantities[item] += quantity;
        cout << "Added " << quantity << " of " << item << ".\n";

        WriteToFile(dataFile);
    }

    void RemoveItem() {
        string item;
        cout << "Enter item name to remove: ";
        getline(cin, item);

        if (itemQuantities.erase(item)) {
            cout << item << " removed successfully.\n";
            WriteToFile(dataFile);
        }
        else {
            cout << "Item not found.\n";
        }
    }

    void UpdateItemQuantity() {
        string item;
        int newQuantity;

        cout << "Enter item name to update: ";
        getline(cin, item);

        if (itemQuantities.find(item) != itemQuantities.end()) {
            cout << "Enter new quantity: ";
            cin >> newQuantity;
            cin.ignore();

            itemQuantities[item] = newQuantity;
            cout << "Updated " << item << " to quantity " << newQuantity << ".\n";

            WriteToFile(dataFile);
        }
        else {
            cout << "Item not found.\n";
        }
    }

    // Menu to interact with the user
    void DisplayMenu() {
        int choice;
        do {
            // Display the main menu options
            cout << "\nGrocery Tracker Menu:\n";
            cout << "1. Look up item Quantity\n";
            cout << "2. Display all items and Quantities\n";
            cout << "3. Display histogram of items\n";
            cout << "4. Exit\n";
            cout << "5. Add an item\n";
            cout << "6. Remove an item\n";
            cout << "7. Update item quantity\n";
            cout << "Enter your choice (1-7): ";
            cin >> choice;
            cin.ignore(); // Clear input buffer to avoid issues with getline

            // Switch statement to handle user's choice
            switch (choice) {
            case 1:
                LookUpItemQuantity(); // Look up specific item Quantity
                break;
            case 2:
                DisplayItemQuantities(); // Display all items and their Quantities
                break;
            case 3:
                DisplayHistogram(); // Display histogram of item Quantities
                break;
            case 4:
                cout << "Exiting the program.\n";
                break;
            case 5:
                AddItem();
                break;
            case 6:
                RemoveItem();
                break;
            case 7:
                UpdateItemQuantity();
                break;
            default:
                cout << "Invalid choice. Please enter a number between 1 and 4.\n";
                break;
            }
        } while (choice != 4); // Loop until the user selects to exit
    }

private:
    map<string, int> itemQuantities; // Map to store item names and their purchase Quantities

    string dataFile;

    // Load data from the file into the map
    void LoadData(const string& filename) {
        ifstream inFile(filename);
        string item;

        if (!inFile) {
            cerr << "Error: Unable to open file " << filename << endl;
            exit(1); // Exit if file cannot be opened
        }

        // Read items from file and update their Quantity count in the map
        int quantity;
        while (inFile >> item >> quantity) {
            itemQuantities[item] = quantity;
        }

        inFile.close(); // Close file after reading
        WriteToFile(dataFile); // Create a backup file with item Quantities
    }

    // Write the Quantities to a backup file
    void WriteToFile(const string& filename) {
        ofstream outFile(filename);
        if (!outFile) {
            cerr << "Error: Unable to write to file " << filename << endl;
            return;
        }

        for (const auto& entry : itemQuantities) {
            outFile << entry.first << " " << entry.second << endl;
        }

        outFile.close();
    }

    // Look up the Quantity of a specific item entered by the user
    void LookUpItemQuantity() {
        string item;
        cout << "Enter the name of the item you want to look up: ";
        cin >> item; // Read user input for the item name

        // Check if the item exists in the map and display its Quantity
        if (itemQuantities.find(item) != itemQuantities.end()) {
            cout << "The item '" << item << "' was purchased " << itemQuantities[item] << " times.\n";
        }
        else {
            cout << "The item '" << item << "' was not found in the records.\n";
        }
    }

    // Display all items and their Quantities
    void DisplayItemQuantities() {
        cout << "\nItems and their Quantities:\n";
        for (const auto& entry : itemQuantities) {
            // Print each item and its corresponding Quantity
            cout << left << setw(15) << entry.first << " " << entry.second << endl;
        }
    }

    // Display a histogram of item Quantities
    void DisplayHistogram() {
        cout << "\nItem Quantity Histogram:\n";
        for (const auto& entry : itemQuantities) {
            // Print item name and asterisks representing its Quantity
            cout << setw(15) << left << entry.first << " ";
            for (int i = 0; i < entry.second; ++i) {
                cout << "*"; // Print an asterisk for each purchase of the item
            }
            cout << endl; // Move to the next line for the next item
        }
    }
};

int main() {
    // Create an instance of GroceryTracker with the input file
    GroceryTracker tracker("CS210_Project_Three_Input_File.txt");
    // Display the menu for user interaction
    tracker.DisplayMenu();

    return 0; // End of program
}
