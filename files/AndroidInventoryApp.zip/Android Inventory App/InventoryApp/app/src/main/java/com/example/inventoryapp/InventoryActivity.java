package com.example.inventoryapp;
import com.example.inventoryapp.AppDatabase;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    Button btnAddItem;
    ItemAdapter adapter;
    AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        recyclerView = findViewById(R.id.recyclerViewInventory);
        btnAddItem = findViewById(R.id.btnAddItem);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        db = AppDatabase.getInstance(this);

        loadItems(); // initial list load

        btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems(); // refresh list when returning to screen
    }

    private void loadItems() {
        List<Item> itemList = db.itemDao().getAllItems();
        adapter = new ItemAdapter(itemList);
        recyclerView.setAdapter(adapter);
    }
}
