package com.example.inventoryapp;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {
    EditText etItemName, etItemQuantity;
    Button btnSaveItem, btnDeleteItem;
    int itemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        etItemName = findViewById(R.id.etItemName);
        etItemQuantity = findViewById(R.id.etItemQuantity);
        btnSaveItem = findViewById(R.id.btnSaveItem);
        btnDeleteItem = findViewById(R.id.btnDeleteItem); // New delete button

        AppDatabase db = AppDatabase.getInstance(this);

        // Check if editing an existing item
        itemId = getIntent().getIntExtra("item_id", -1);
        if (itemId != -1) {
            Item existingItem = db.itemDao().getItemById(itemId);
            if (existingItem != null) {
                etItemName.setText(existingItem.name);
                etItemQuantity.setText(String.valueOf(existingItem.quantity));
                btnDeleteItem.setVisibility(View.VISIBLE); // Only show delete if editing
            }
        } else {
            btnDeleteItem.setVisibility(View.GONE); // Hide delete when adding new item
        }

        btnSaveItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = etItemName.getText().toString().trim();
                String qtyText = etItemQuantity.getText().toString().trim();

                if (!name.isEmpty() && !qtyText.isEmpty()) {
                    try {
                        int quantity = Integer.parseInt(qtyText);

                        if (itemId != -1) {
                            // Update existing item
                            Item updatedItem = new Item(name, quantity);
                            updatedItem.id = itemId;
                            db.itemDao().update(updatedItem);
                            Toast.makeText(AddItemActivity.this, "Item updated!", Toast.LENGTH_SHORT).show();
                        } else {
                            // Insert new item
                            Item newItem = new Item(name, quantity);
                            db.itemDao().insert(newItem);
                            Toast.makeText(AddItemActivity.this, "Item saved!", Toast.LENGTH_SHORT).show();
                        }

                        new Handler().postDelayed(() -> finish(), 300);

                    } catch (NumberFormatException e) {
                        Toast.makeText(AddItemActivity.this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(AddItemActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDeleteItem.setOnClickListener(view -> {
            if (itemId != -1) {
                Item toDelete = db.itemDao().getItemById(itemId);
                if (toDelete != null) {
                    db.itemDao().delete(toDelete);
                    Toast.makeText(AddItemActivity.this, "Item deleted!", Toast.LENGTH_SHORT).show();
                    new Handler().postDelayed(() -> finish(), 300);
                }
            }
        });
    }
}
